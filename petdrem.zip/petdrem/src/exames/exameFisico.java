package exames;

public class exameFisico {

    private String postura;
    private String nivelDeConciencia;
    private String escoreCorporal;
    private String hidratação;
    private String linfonodosSubmand;
    private String linfPre_esxapulares;
    private String linfPopliteos;
    private String linfInguinais;
    private String Mucosaocular;
    private String mucosaOral;
    private String mucosaPenianaOuVulvar;
    private String mucosaAnal;
    private String trCº;
    private String frBpm;
    private String tcpSeg;
    private String pulsoPpm;

    private exameFisico(){

    }

    public exameFisico(String postura, String nivelDeConciencia, String escoreCorporal, String hidratação, String linfonodosSubmand, String linfPre_esxapulares, String linfPopliteos, String linfInguinais, String mucosaocular, String mucosaOral, String mucosaPenianaOuVulvar, String mucosaAnal, String trCº, String frBpm, String tcpSeg, String pulsoPpm) {
        this.postura = postura;
        this.nivelDeConciencia = nivelDeConciencia;
        this.escoreCorporal = escoreCorporal;
        this.hidratação = hidratação;
        this.linfonodosSubmand = linfonodosSubmand;
        this.linfPre_esxapulares = linfPre_esxapulares;
        this.linfPopliteos = linfPopliteos;
        this.linfInguinais = linfInguinais;
        Mucosaocular = mucosaocular;
        this.mucosaOral = mucosaOral;
        this.mucosaPenianaOuVulvar = mucosaPenianaOuVulvar;
        this.mucosaAnal = mucosaAnal;
        this.trCº = trCº;
        this.frBpm = frBpm;
        this.tcpSeg = tcpSeg;
        this.pulsoPpm = pulsoPpm;
    }

    public String getPostura() {
        return postura;
    }

    public void setPostura(String postura) {
        this.postura = postura;
    }

    public String getNivelDeConciencia() {
        return nivelDeConciencia;
    }

    public void setNivelDeConciencia(String nivelDeConciencia) {
        this.nivelDeConciencia = nivelDeConciencia;
    }

    public String getEscoreCorporal() {
        return escoreCorporal;
    }

    public void setEscoreCorporal(String escoreCorporal) {
        this.escoreCorporal = escoreCorporal;
    }

    public String getHidratação() {
        return hidratação;
    }

    public void setHidratação(String hidratação) {
        this.hidratação = hidratação;
    }

    public String getLinfonodosSubmand() {
        return linfonodosSubmand;
    }

    public void setLinfonodosSubmand(String linfonodosSubmand) {
        this.linfonodosSubmand = linfonodosSubmand;
    }

    public String getLinfPre_esxapulares() {
        return linfPre_esxapulares;
    }

    public void setLinfPre_esxapulares(String linfPre_esxapulares) {
        this.linfPre_esxapulares = linfPre_esxapulares;
    }

    public String getLinfPopliteos() {
        return linfPopliteos;
    }

    public void setLinfPopliteos(String linfPopliteos) {
        this.linfPopliteos = linfPopliteos;
    }

    public String getLinfInguinais() {
        return linfInguinais;
    }

    public void setLinfInguinais(String linfInguinais) {
        this.linfInguinais = linfInguinais;
    }

    public String getMucosaocular() {
        return Mucosaocular;
    }

    public void setMucosaocular(String mucosaocular) {
        Mucosaocular = mucosaocular;
    }

    public String getMucosaOral() {
        return mucosaOral;
    }

    public void setMucosaOral(String mucosaOral) {
        this.mucosaOral = mucosaOral;
    }

    public String getMucosaPenianaOuVulvar() {
        return mucosaPenianaOuVulvar;
    }

    public void setMucosaPenianaOuVulvar(String mucosaPenianaOuVulvar) {
        this.mucosaPenianaOuVulvar = mucosaPenianaOuVulvar;
    }

    public String getMucosaAnal() {
        return mucosaAnal;
    }

    public void setMucosaAnal(String mucosaAnal) {
        this.mucosaAnal = mucosaAnal;
    }

    public String getTrCº() {
        return trCº;
    }

    public void setTrCº(String trCº) {
        this.trCº = trCº;
    }

    public String getFrBpm() {
        return frBpm;
    }

    public void setFrBpm(String frBpm) {
        this.frBpm = frBpm;
    }

    public String getTcpSeg() {
        return tcpSeg;
    }

    public void setTcpSeg(String tcpSeg) {
        this.tcpSeg = tcpSeg;
    }

    public String getPulsoPpm() {
        return pulsoPpm;
    }

    public void setPulsoPpm(String pulsoPpm) {
        this.pulsoPpm = pulsoPpm;
    }
}
