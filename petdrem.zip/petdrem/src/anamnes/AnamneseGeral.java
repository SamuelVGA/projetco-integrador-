package anamnes;

public class AnamneseGeral {
    private String queixaPrincipal;
    private String historicoMedicoProgreso;
    private String alimentação;
    private String contactantes;
    private String ambienteEmQueVive;
    private String vacinação;
    private String vermifugação;

    public AnamneseGeral(){

    }

    public AnamneseGeral(String queixaPrincipal, String historicoMedicoProgreso, String alimentação, String contactantes, String ambienteEmQueVive, String vacinação, String vermifugação) {
        this.queixaPrincipal = queixaPrincipal;
        this.historicoMedicoProgreso = historicoMedicoProgreso;
        this.alimentação = alimentação;
        this.contactantes = contactantes;
        this.ambienteEmQueVive = ambienteEmQueVive;
        this.vacinação = vacinação;
        this.vermifugação = vermifugação;
    }

    public String getQueixaPrincipal() {
        return queixaPrincipal;
    }

    public void setQueixaPrincipal(String queixaPrincipal) {
        this.queixaPrincipal = queixaPrincipal;
    }

    public String getHistoricoMedicoProgreso() {
        return historicoMedicoProgreso;
    }

    public void setHistoricoMedicoProgreso(String historicoMedicoProgreso) {
        this.historicoMedicoProgreso = historicoMedicoProgreso;
    }

    public String getAlimentação() {
        return alimentação;
    }

    public void setAlimentação(String alimentação) {
        this.alimentação = alimentação;
    }

    public String getContactantes() {
        return contactantes;
    }

    public void setContactantes(String contactantes) {
        this.contactantes = contactantes;
    }

    public String getAmbienteEmQueVive() {
        return ambienteEmQueVive;
    }

    public void setAmbienteEmQueVive(String ambienteEmQueVive) {
        this.ambienteEmQueVive = ambienteEmQueVive;
    }

    public String getVacinação() {
        return vacinação;
    }

    public void setVacinação(String vacinação) {
        this.vacinação = vacinação;
    }

    public String getVermifugação() {
        return vermifugação;
    }

    public void setVermifugação(String vermifugação) {
        this.vermifugação = vermifugação;
    }
}
