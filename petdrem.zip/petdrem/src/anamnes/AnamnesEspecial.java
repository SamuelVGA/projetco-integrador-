package anamnes;

public class AnamnesEspecial {
    private String sistemaRespiratorio;
    private String sistemaCardiovascular;
    private String sistemaDigestorio;
    private String sistemaUrinari;
    private String sistemaReprodutor;
    private String sistemaLocomotor;
    private String sistemaimunologico;
    private String peleEanexos;
    private String olhos;

    public AnamnesEspecial(){

    }

    public AnamnesEspecial(String sistemaRespiratorio, String sistemaCardiovascular, String sistemaDigestorio, String sistemaUrinari, String sistemaReprodutor, String sistemaLocomotor, String sistemaimunologico, String peleEanexos, String olhos) {
        this.sistemaRespiratorio = sistemaRespiratorio;
        this.sistemaCardiovascular = sistemaCardiovascular;
        this.sistemaDigestorio = sistemaDigestorio;
        this.sistemaUrinari = sistemaUrinari;
        this.sistemaReprodutor = sistemaReprodutor;
        this.sistemaLocomotor = sistemaLocomotor;
        this.sistemaimunologico = sistemaimunologico;
        this.peleEanexos = peleEanexos;
        this.olhos = olhos;
    }

    public String getSistemaRespiratorio() {
        return sistemaRespiratorio;
    }

    public void setSistemaRespiratorio(String sistemaRespiratorio) {
        this.sistemaRespiratorio = sistemaRespiratorio;
    }

    public String getSistemaCardiovascular() {
        return sistemaCardiovascular;
    }

    public void setSistemaCardiovascular(String sistemaCardiovascular) {
        this.sistemaCardiovascular = sistemaCardiovascular;
    }

    public String getSistemaDigestorio() {
        return sistemaDigestorio;
    }

    public void setSistemaDigestorio(String sistemaDigestorio) {
        this.sistemaDigestorio = sistemaDigestorio;
    }

    public String getSistemaUrinari() {
        return sistemaUrinari;
    }

    public void setSistemaUrinari(String sistemaUrinari) {
        this.sistemaUrinari = sistemaUrinari;
    }

    public String getSistemaReprodutor() {
        return sistemaReprodutor;
    }

    public void setSistemaReprodutor(String sistemaReprodutor) {
        this.sistemaReprodutor = sistemaReprodutor;
    }

    public String getSistemaLocomotor() {
        return sistemaLocomotor;
    }

    public void setSistemaLocomotor(String sistemaLocomotor) {
        this.sistemaLocomotor = sistemaLocomotor;
    }

    public String getSistemaimunologico() {
        return sistemaimunologico;
    }

    public void setSistemaimunologico(String sistemaimunologico) {
        this.sistemaimunologico = sistemaimunologico;
    }

    public String getPeleEanexos() {
        return peleEanexos;
    }

    public void setPeleEanexos(String peleEanexos) {
        this.peleEanexos = peleEanexos;
    }

    public String getOlhos() {
        return olhos;
    }

    public void setOlhos(String olhos) {
        this.olhos = olhos;
    }
}
