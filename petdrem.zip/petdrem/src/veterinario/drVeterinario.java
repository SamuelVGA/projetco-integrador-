package veterinario;

import java.util.Date;

public class drVeterinario {

    private Integer crmv;
    private String nome;
    private String gmail;
    private Date datadenascimento;

    public drVeterinario(){

    }

    public drVeterinario(Integer crmv, String nome, String gmail, Date datadenascimento) {
        this.crmv = crmv;
        this.nome = nome;
        this.gmail = gmail;
        this.datadenascimento = datadenascimento;
    }

    public Integer getCrmv() {
        return crmv;
    }

    public void setCrmv(Integer crmv) {
        this.crmv = crmv;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getGmail() {
        return gmail;
    }

    public void setGmail(String gmail) {
        this.gmail = gmail;
    }

    public Date getDatadenascimento() {
        return datadenascimento;
    }

    public void setDatadenascimento(Date datadenascimento) {
        this.datadenascimento = datadenascimento;
    }
}
