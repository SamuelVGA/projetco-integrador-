package agendamento;

import java.util.Date;

public class agendamentoConsulta {

    private Date agendamentocolsulta;
    private String nomeDoveterinario;
    private String tipoDeagendamento;
    private String observações;
    private String Animal;

    public agendamentoConsulta(){

    }

    public agendamentoConsulta(Date agendamentocolsulta, String nomeDoveterinario, String tipoDeagendamento, String observações, String animal) {
        this.agendamentocolsulta = agendamentocolsulta;
        this.nomeDoveterinario = nomeDoveterinario;
        this.tipoDeagendamento = tipoDeagendamento;
        this.observações = observações;
        Animal = animal;
    }

    public Date getAgendamentocolsulta() {
        return agendamentocolsulta;
    }

    public void setAgendamentocolsulta(Date agendamentocolsulta) {
        this.agendamentocolsulta = agendamentocolsulta;
    }

    public String getNomeDoveterinario() {
        return nomeDoveterinario;
    }

    public void setNomeDoveterinario(String nomeDoveterinario) {
        this.nomeDoveterinario = nomeDoveterinario;
    }

    public String getTipoDeagendamento() {
        return tipoDeagendamento;
    }

    public void setTipoDeagendamento(String tipoDeagendamento) {
        this.tipoDeagendamento = tipoDeagendamento;
    }

    public String getObservações() {
        return observações;
    }

    public void setObservações(String observações) {
        this.observações = observações;
    }

    public String getAnimal() {
        return Animal;
    }

    public void setAnimal(String animal) {
        Animal = animal;
    }
}
