package idetificador;

import java.util.Date;

public class donoDopet {

    private String nome;
    private String RG;
    private String endereço;
    private String cidade;
    private String uf;
    private String celular;
    private String telefone;
    private Date dataDoprocedimento;

    public donoDopet(){

    }

    public donoDopet(String nome, String RG, String endereço, String cidade, String uf, String celular, String telefone, Date dataDoprocedimento) {
        this.nome = nome;
        this.RG = RG;
        this.endereço = endereço;
        this.cidade = cidade;
        this.uf = uf;
        this.celular = celular;
        this.telefone = telefone;
        this.dataDoprocedimento = dataDoprocedimento;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRG() {
        return RG;
    }

    public void setRG(String RG) {
        this.RG = RG;
    }

    public String getEndereço() {
        return endereço;
    }

    public void setEndereço(String endereço) {
        this.endereço = endereço;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public Date getDataDoprocedimento() {
        return dataDoprocedimento;
    }

    public void setDataDoprocedimento(Date dataDoprocedimento) {
        this.dataDoprocedimento = dataDoprocedimento;
    }
}
