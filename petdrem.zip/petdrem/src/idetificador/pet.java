package idetificador;

public class pet {
    private String nome;
    private String raça;
    private String sexo;
    private String idade;
    private String peso;
    private String pelagem;
    private String procedencia;

    public pet(){

    }

    public pet(String nome, String raça, String sexo, String idade, String peso, String pelagem, String procedencia) {
        this.nome = nome;
        this.raça = raça;
        this.sexo = sexo;
        this.idade = idade;
        this.peso = peso;
        this.pelagem = pelagem;
        this.procedencia = procedencia;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRaça() {
        return raça;
    }

    public void setRaça(String raça) {
        this.raça = raça;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getIdade() {
        return idade;
    }

    public void setIdade(String idade) {
        this.idade = idade;
    }

    public String getPeso() {
        return peso;
    }

    public void setPeso(String peso) {
        this.peso = peso;
    }

    public String getPelagem() {
        return pelagem;
    }

    public void setPelagem(String pelagem) {
        this.pelagem = pelagem;
    }

    public String getProcedencia() {
        return procedencia;
    }

    public void setProcedencia(String procedencia) {
        this.procedencia = procedencia;
    }
}
